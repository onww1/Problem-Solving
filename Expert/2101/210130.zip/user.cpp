void test(unsigned char* FREQ, const unsigned char* BITMAP) {
    
}

void comp(unsigned char* COMP, const unsigned char* FREQ) {
    
}

void decomp(unsigned char* FREQ, const unsigned char* COMP) {

}